This directory contains a registry of performance tests carried out by 
the program 'mrpt-performance'. See its code for further reference.


