This directory contains an example of a minimal user application which 
uses the MRPT libraries, using a Makefile build system (instead of CMake).

The Makefile file contains comments explaining the usage of pkg-config
with MRPT to obtain the required -I -L and -l flags to build user programs.


Build invoking:

$ make

