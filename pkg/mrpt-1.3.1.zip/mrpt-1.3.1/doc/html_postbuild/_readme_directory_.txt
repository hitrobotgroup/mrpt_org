This directory contains those files to be copied unmodified to "doc/html" 
after invoking doxygen.

Jose Luis Blanco, Jan 2008


