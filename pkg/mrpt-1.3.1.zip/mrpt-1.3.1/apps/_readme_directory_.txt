The "apps" directory holds complete, functional applications using the MRPT library. 
For simpler examples see the directory "samples".

    ~~  The MRPT Library  ~~
    Jose Luis Blanco, AUG-2007



