/* +---------------------------------------------------------------------------+
   |                     Mobile Robot Programming Toolkit (MRPT)               |
   |                          http://www.mrpt.org/                             |
   |                                                                           |
   | Copyright (c) 2005-2015, Individual contributors, see AUTHORS file        |
   | See: http://www.mrpt.org/Authors - All rights reserved.                   |
   | Released under BSD License. See details in http://www.mrpt.org/License    |
   +---------------------------------------------------------------------------+ */

#ifndef _mrpt_math_old_H
#define _mrpt_math_old_H

#include <mrpt/utils/utils_defs.h>
MRPT_WARNING("This is an old header, please replace with <mrpt/math.h>");
#include <mrpt/math.h>

#endif
