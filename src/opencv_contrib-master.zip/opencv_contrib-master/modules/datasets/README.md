Interface for interfacing with existing computer vision databases 
=================================================================
