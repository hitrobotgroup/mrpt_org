Custom Calibration Pattern for 3D reconstruction
================================================
