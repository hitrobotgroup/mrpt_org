Improved Background-Foreground Segmentation Methods 
===================================================

1. Adaptive Background Mixture Model for Real-time Tracking
2. Visual Tracking of Human Visitors under Variable-Lighting Conditions.